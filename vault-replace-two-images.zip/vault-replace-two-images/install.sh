#!/usr/bin/env bash
set -euo pipefail
BRANCH='chore/final-vault-images-only'
ROOT=$(git rev-parse --show-toplevel 2>/dev/null) || { echo 'Open this in the Vault Codespaces Terminal.' >&2; exit 1; }
ASSETS=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$ROOT"
if ! git diff --quiet || ! git diff --cached --quiet; then echo 'Uncommitted tracked changes found. Commit/stash first; no files altered.' >&2; exit 1; fi
git fetch origin "$BRANCH"
git switch "$BRANCH"
git pull --ff-only origin "$BRANCH"
cp -- "$ASSETS/public/icons/anime_tracker_app_icon.png" public/icons/anime_tracker_app_icon.png
cp -- "$ASSETS/public/images/anime_tracker_loading_screen-1.png" public/images/anime_tracker_loading_screen-1.png
printf '%s  %s\n' \
 '84e79d6a76c4902d7f79bb238f3927866e7158095fcf1cb3fc67d9652591c496' public/icons/anime_tracker_app_icon.png \
 '8b3a5d8a1b31355df413089178ad9fe3d73ff78dd085ec3a69445499ff975e84' public/images/anime_tracker_loading_screen-1.png | sha256sum -c -
git add -- public/icons/anime_tracker_app_icon.png public/images/anime_tracker_loading_screen-1.png
if git diff --cached --quiet; then echo 'Final images already match. Nothing to commit.'; exit 0; fi
git commit -m 'Replace Vault PWA icon and startup image with final unchanged uploads'
git push origin HEAD
echo 'Both final images replaced in PR #13, same filenames. No other image edits.'
